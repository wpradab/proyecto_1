import tensorflow_transform as tft

def preprocessing_fn(inputs):
    """Preprocess input columns into transformed columns."""
    outputs = {}
    # Escala las características numéricas al rango [0, 1]
    for feature in ['Elevation', 'Horizontal_Distance_To_Roadways']:
        outputs[feature] = tft.scale_to_0_1(inputs[feature])
    
    # Aplica hashing a las características categóricas
    for feature in ['Soil_Type_C2703', 'Soil_Type_C2704','Soil_Type_C2705','Soil_Type_C2717', 'Soil_Type_C4703','Soil_Type_C8771', 'Soil_Type_C8772','Wilderness_Area_Rawah']:
        outputs[feature] = tft.compute_and_apply_vocabulary(inputs[feature], num_oov_buckets=1)
    
    # Añade más transformaciones según sea necesario
    
    return outputs
