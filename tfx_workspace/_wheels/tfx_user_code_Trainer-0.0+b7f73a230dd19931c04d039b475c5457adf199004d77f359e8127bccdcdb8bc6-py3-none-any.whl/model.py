# model.py
import tensorflow as tf
from tfx.components.trainer.executor import TrainerFnArgs

def run_fn(fn_args):
    # Asume que has determinado NUM_CLASSES basado en tu dataset
    NUM_CLASSES = 7  # Ajusta según tu caso
    
    # Definición del modelo
    model = tf.keras.models.Sequential([
        tf.keras.layers.Dense(128, activation='relu', input_shape=(NUM_FEATURES,)),  # Ajusta según tu caso
        tf.keras.layers.Dense(64, activation='relu'),
        tf.keras.layers.Dense(NUM_CLASSES, activation='softmax')
    ])
    
    model.compile(optimizer='adam',
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])
    
    # Cargar el dataset de entrenamiento y evaluación
    train_dataset = _input_fn(fn_args.train_files, feature_spec, batch_size=32)
    eval_dataset = _input_fn(fn_args.eval_files, feature_spec, batch_size=32)
    
    # Entrenar el modelo
    model.fit(train_dataset,
              steps_per_epoch=fn_args.train_steps,
              validation_data=eval_dataset,
              validation_steps=fn_args.eval_steps,
              epochs=fn_args.num_epochs)
    
    # Guardar el modelo entrenado
    model.save(fn_args.serving_model_dir)
