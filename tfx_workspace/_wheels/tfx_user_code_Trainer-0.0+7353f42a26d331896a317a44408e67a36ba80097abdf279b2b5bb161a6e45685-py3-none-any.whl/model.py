# model.py
# model.py
import tensorflow as tf
from tfx.components.trainer.executor import TrainerFnArgs
from tensorflow.keras.layers import Dense
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.losses import SparseCategoricalCrossentropy
from tensorflow.keras.metrics import SparseCategoricalAccuracy, Precision, Recall

def run_fn(fn_args: TrainerFnArgs):
    # Número de clases, ajusta según tu caso de uso
    NUM_CLASSES = 3  # Ajusta este valor al número de clases que tengas
    
    # Definición del modelo
    model = Sequential([
        Dense(128, activation='relu', input_shape=(fn_args.train_steps,)),  # Ajusta según la forma de tus características
        Dense(64, activation='relu'),
        Dense(NUM_CLASSES, activation='softmax')
    ])
    
    model.compile(optimizer=Adam(),
                  loss=SparseCategoricalCrossentropy(),
                  metrics=[SparseCategoricalAccuracy(name='accuracy'),
                           Precision(name='precision'),
                           Recall(name='recall')])
    
    # Cargar el conjunto de datos de entrenamiento y evaluación
    train_dataset = "tfx_workspace/data/covertype_train.csv"  # Carga tus datos de entrenamiento aquí
    eval_dataset = "tfx_workspace/data/covertype_test.csv"  # Carga tus datos de evaluación aquí

    # Entrenar el modelo
    model.fit(train_dataset,
              steps_per_epoch=fn_args.train_steps,
              validation_data=eval_dataset,
              validation_steps=fn_args.eval_steps,
              epochs=fn_args.num_epochs)  # Asegúrate de haber definido num_epochs en TrainerFnArgs
    
    # Guardar el modelo entrenado
    model.save(fn_args.serving_model_dir)
