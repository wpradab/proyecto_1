# model.py
import tensorflow as tf
from tfx.components.trainer.executor import TrainerFnArgs
from tfx_bsl.tfxio import dataset_options

def _input_fn(file_pattern, feature_spec, batch_size):
    # Esta función debe implementarse para leer los datos de entrada
    # A continuación, se muestra un ejemplo genérico
    # Asegúrate de ajustar esta función según tus necesidades
    return tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=feature_spec,
        reader=tf.data.TFRecordDataset,
        label_key='Cover_type')  # Ajusta 'tu_label_key_aquí' al nombre de tu etiqueta en el dataset

def run_fn(fn_args: TrainerFnArgs):
    # Asume que has determinado NUM_CLASSES basado en tu dataset
    NUM_CLASSES = 7  # Ajusta según tu caso
    
    # Debes definir NUM_FEATURES aquí. Por ejemplo:
    NUM_FEATURES = 20  # Este número debe coincidir con la cantidad de características de tu dataset
    
    # Definición del modelo
    model = tf.keras.models.Sequential([
        tf.keras.layers.Dense(128, activation='relu', input_shape=(NUM_FEATURES,)),
        tf.keras.layers.Dense(64, activation='relu'),
        tf.keras.layers.Dense(NUM_CLASSES, activation='softmax')
    ])
    
    model.compile(optimizer='adam',
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])
    
    # Define tu feature_spec aquí. Esto debe coincidir con cómo preparaste tus datos para TFX
    feature_spec = {
        'Elevation': tf.io.FixedLenFeature([], tf.float32),
        'Horizontal_Distance_To_Roadways': tf.io.FixedLenFeature([], tf.float32),
        'Soil_Type_C2703': tf.io.FixedLenFeature([], tf.int64),
        'Soil_Type_C2704': tf.io.FixedLenFeature([], tf.int64),
        'Soil_Type_C2705': tf.io.FixedLenFeature([], tf.int64),
        'Soil_Type_C2717': tf.io.FixedLenFeature([], tf.int64),
        'Soil_Type_C4703': tf.io.FixedLenFeature([], tf.int64),
        'Soil_Type_C8771': tf.io.FixedLenFeature([], tf.int64),
        'Soil_Type_C8772': tf.io.FixedLenFeature([], tf.int64),
        'Wilderness_Area_Rawah': tf.io.FixedLenFeature([], tf.int64),
        # Asumimos que 'Cover_Type' es la etiqueta y no una característica de entrada
    }
    
    NUM_FEATURES = len(feature_spec)  # Ajusta según tu caso

    # Cargar el dataset de entrenamiento y evaluación
    train_dataset = _input_fn(fn_args.train_files, feature_spec, batch_size=32)
    eval_dataset = _input_fn(fn_args.eval_files, feature_spec, batch_size=32)
    
    # Entrenar el modelo
    model.fit(train_dataset,
              steps_per_epoch=fn_args.train_steps,
              validation_data=eval_dataset,
              validation_steps=fn_args.eval_steps,
              epochs=fn_args.num_epochs)
    
    # Guardar el modelo entrenado
    model.save(fn_args.serving_model_dir)
