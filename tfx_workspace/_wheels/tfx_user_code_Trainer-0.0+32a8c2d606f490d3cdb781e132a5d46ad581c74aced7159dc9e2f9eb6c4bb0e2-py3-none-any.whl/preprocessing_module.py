import tensorflow_transform as tft

def preprocessing_fn(inputs):
    """Función de preprocesamiento para el componente Transform de TFX."""
    outputs = {}

    # Aplica escalamiento Min-Max a las características numéricas
    for key in ['Elevation', 'Aspect', 'Slope', 'Horizontal_Distance_To_Hydrology', 'Vertical_Distance_To_Hydrology']:
        outputs[key] = tft.scale_to_0_1(inputs[key])
    
    # Aplica one-hot encoding a las características categóricas
    for key in ['Soil_Type', 'Wilderness_Area']:
        outputs[key] = tft.compute_and_apply_vocabulary(inputs[key])
    
    # No necesita transformación para la variable objetivo
    outputs['Cover_Type'] = inputs['Cover_Type']
    
    return outputs
